import os
import json
import urllib.request
import urllib.error

def handler(event, context):
    """
    Simple Lambda handler that demonstrates connectivity by fetching public IP
    """
    print("Event received:", event)
    
    # Get deployment mode and request info
    deployment_mode = os.environ.get('DEPLOYMENT_MODE', 'Unknown')
    
    # Extract source IP from the API Gateway event
    source_ip = "Unknown"
    if 'requestContext' in event and 'identity' in event['requestContext']:
        source_ip = event['requestContext']['identity'].get('sourceIp', 'Unknown')
    elif 'headers' in event and 'X-Forwarded-For' in event['headers']:
        source_ip = event['headers']['X-Forwarded-For'].split(',')[0].strip()
    
    # Get the requested path
    path = event.get('path', '/').rstrip('/')
    if not path:
        path = '/'
    
    try:
        # Main route
        if path == '/' or path == '':
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'text/html'},
                'body': generate_home_page(source_ip, deployment_mode)
            }
        # Check outbound connectivity
        elif path == '/getmyip':
            outbound_ip = get_outbound_ip()
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'text/html'},
                'body': generate_getmyip_page(outbound_ip, deployment_mode)
            }
        # Health check
        elif path == '/health':
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'text/plain'},
                'body': 'OK'
            }
        # 404 for unknown paths
        else:
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'text/html'},
                'body': '<h1>404 Not Found</h1><p>The requested path was not found.</p>'
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'text/html'},
            'body': generate_error_page(str(e), deployment_mode)
        }

def get_outbound_ip():
    """Get the outbound IP address by calling an external service"""
    try:
        with urllib.request.urlopen('https://ifconfig.me/ip', timeout=5) as response:
            return response.read().decode('utf-8').strip()
    except urllib.error.URLError as e:
        raise Exception(f"Error fetching outbound IP: {str(e)}")

def generate_home_page(source_ip, deployment_mode):
    """Generate the HTML for the home page"""
    return f"""
    <html>
    <head>
        <title>AWS Private Connectivity Demo</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; }}
            h1 {{ color: #232f3e; }}
        </style>
    </head>
    <body>
        <h1>AWS Private Connectivity Demo</h1>
        <h2>Inbound Connection Information</h2>
        <p>Your request came from IP: <strong>{source_ip}</strong></p>
        <p><a href="/getmyip">Check My Outbound IP</a></p>
        <p>Deployment Mode: <strong>{deployment_mode}</strong></p>
    </body>
    </html>
    """

def generate_getmyip_page(outbound_ip, deployment_mode):
    """Generate the HTML for the getmyip page"""
    return f"""
    <html>
    <head>
        <title>AWS Private Connectivity Demo - Outbound IP</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; }}
            h1 {{ color: #232f3e; }}
        </style>
    </head>
    <body>
        <h1>AWS Private Connectivity Demo</h1>
        <h2>Outbound Connection Information</h2>
        <p>My outbound IP: <strong>{outbound_ip}</strong></p>
        <p>Deployment Mode: <strong>{deployment_mode}</strong></p>
        <p><a href="/">Back to Home</a></p>
    </body>
    </html>
    """

def generate_error_page(error_message, deployment_mode):
    """Generate the HTML for the error page"""
    return f"""
    <html>
    <head>
        <title>AWS Private Connectivity Demo - Error</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; }}
            h1 {{ color: #232f3e; }}
        </style>
    </head>
    <body>
        <h1>AWS Private Connectivity Demo</h1>
        <h2>Outbound Connection Error</h2>
        <p>Error: <strong>{error_message}</strong></p>
        <p>This might be because outbound internet access is restricted.</p>
        <p>Deployment Mode: <strong>{deployment_mode}</strong></p>
        <p><a href="/">Back to Home</a></p>
    </body>
    </html>
    """
